function openAgarWoodAddPage(){
    window.location='./notificationAddEdit.html';
}
