function openCommisionAddPage(){
    window.location='./comissionAddEdit.html';
}

function openCommisionUpdatePage(){
    window.location='./comissionEdit.html';
}


$(document).ready(function(){
         
});
